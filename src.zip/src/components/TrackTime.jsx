import { SimpleGrid } from "@chakra-ui/react";
import { Box, Text } from "@chakra-ui/react";
import React from "react";
import { FiEdit } from "react-icons/fi";
import { Checkbox } from "@chakra-ui/react";
import { Button } from "@chakra-ui/react";

  //  track time page
function TrackTime() {
   
    const [buttonClicked,setButtonClicked]=useState(1)
    const handleButton=(num)=>{
        setButtonClicked(num)
    }

  const Date = [
    {
      date: 15,
      day: "Mon",
    },
    {
      date: 16,
      day: "Tue",
    },
    {
      date: 17,
      day: "Wed",
    },
    {
      date: 18,
      day: "Thu",
    },
    {
      date: 19,
      day: "Fri",
    },
    {
      date: 20,
      day: "Sat",
    },
    {
      date: 21,
      day: "Sun",
    },
    {
      date: 22,
      day: "Mon",
    },
    {
      date: 23,
      day: "Tue",
    },
  ];

  const schedules = [
    {
      time: "9:00 AM",
      title: "HR Interview",
    },
    {
      time: "9:00 AM",
      title: "Client meeting",
    },
    {
      time: "9:00 AM",
      title: "Review with UX Team",
    },
    {
      time: "9:00 AM",
      title: "Team Meeting",
    },
    {
      time: "9:00 AM",
      title: "Stakholder Meeting",
    },
  ];
  return (
    <SimpleGrid py={"2rem"}>
      {/* main div */}

      {/*calendar  */}

      <Box display={"flex"} gap={"2rem"}>
        <Box w="75%">
          <Box
            display={"flex"}
            alignItems={"center"}
            justifyContent={"center"}
            gap={"2rem"}
            ml={"1rem"}
            boxShadow="md"
            h="100px"
            bg={"red"}
            buttonClicked={buttonClicked}
            handleButtonClicked={handleButtonClicked}
          >
            {Date.map((item) => (
              <Calendar date={item.date} day={item.day} />
            ))}
          </Box>
          {/* time */}
          <Box ml={"1rem"}>
            <Text>Hello</Text>
          </Box>
        </Box>
        {/* calender2 */}
        <Box>
          <Box w="25%">
            <Text>Hello</Text>
          </Box>

          {/* schedule list */}
          <Box boxShadow="md" w="300px" h="400px">
            <Box
              display={"flex"}
              gap={"2rem"}
              justifyContent={"space-between"}
              py={"1rem"}
              justifyItems={"center"}
              ml={"2rem"}
            >
              <Box>
                <Text>Today's Schedules</Text>
              </Box>
              <Box display={"flex"} mr={"2rem"}>
                <FiEdit size={12} />
                <Text>0/5</Text>
              </Box>
            </Box>
            {schedules.map((data) => (
              <ScheduleList time={data.time} title={data.title} />
            ))}
            <Box >
              <Button
                colorScheme="teal"
                size="md"
                w="150px"
                mx="auto"
                alignItems={"center"}
                ml={"5rem"}
              >
                Click Me
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>
    </SimpleGrid>
  );
}
// calender
const Calendar = ({ date, day }) => (
  <Box
    bg={"#FFFFFF"}
    textAlign={"center"}
    ml={"1rem"}
    fontFamily="poppins"
    fontWeight={400}
    fontSize={"20px"}
  >
    <Text>{date}</Text>
    <Text>{day}</Text>
  </Box>
);
export default TrackTime;

// Schedulelist
const ScheduleList = ({ time, title }) => (
  <Box ml={"2rem"}>
    <Box display={"flex"} justifyContent={"space-between"}>
      <Box mt={"1rem"}>
        <Text>{time}</Text>
        <Text>{title}</Text>
      </Box>
      <Box mr={"2rem"}>
        <Checkbox value="checkbox1"></Checkbox>
      </Box>
    </Box>
  </Box>
);
