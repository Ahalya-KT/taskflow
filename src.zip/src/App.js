import "./App.css";
import { ChakraProvider } from "@chakra-ui/react";
import Home from "./pages/Home";
import Taskflow from "./components/Taskflow";
import Task from "./components/Task";
import TrackTime from "./components/TrackTime";

function App() {
  return (
    <div className="App">
      <ChakraProvider>
      <TrackTime/>
      </ChakraProvider>
    </div>
  );
}

export default App;
